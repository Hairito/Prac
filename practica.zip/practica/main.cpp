#include "Huffman.hpp"

using namespace std;

//////////////////////////////////////////////////////

	/*Falta:
		-Recorrer arbre de frequencies i crear codificacions.
		-Cambiar frequencies a base 1.
	*/

//////////////////////////////////////////////////////

int main (){
	
	// 1. Lectura del text d'entrada
	string input;
	//cin >> input;
	getline(cin, input);
	// 2. Creació de la taula de freqüències
	TaulaFreq freqtab;
	freqtab.construirTaula(input);
	// 3. Obtenció dels codis de Huffman
	Huffman huff(freqtab);
	// 4. Codificació Huffman d'un missatge de text
	huff.inserirCodis();
	huff.mostrarCodis();
		// 4.1 Mostrar el text d'entrada original
	cout << " Missatge d'entrada (com a string):" << endl;
	cout << input << endl;
		// 4.2 Mostrar el text d'entrada amb la codificació Huffman
	cout << " Missatge codificat (com a string):" << endl;
	string output;
	output = huff.codificar(input);
	cout << output << endl;
	
}

/*
int main() {

	string input;
	vector<Entrada> ent;
	cin >> input;

	TaulaFreq freqtab;
	freqtab.construirTaula(input);
	freqtab.mostrarTaula();
	Huffman huff(freqtab);
	cout << 1 << endl;
	huff.inserirCodis();
	cout << 2 << endl;
	huff.mostrarCodis();
	cout << 3 << endl;
	int x,y,z;
	cin >> x >> y >> z;
	Queue<int> qu;
	qu.push(x);
	cout << 000000 << endl;
	qu.push(y);
	cout << 000000 << endl;
	qu.push(z);
	cout << qu << endl;
}
*/